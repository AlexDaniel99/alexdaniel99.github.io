# LX Play 1.0

Primeira versão da página inicial do LX Play.

## Como testar
Abra o arquivo `index.html` no navegador.

## Como personalizar
- Textos e títulos: `index.html`
- Visual: `style.css`
- Busca e interações: `script.js`

## Importante
Os jogos e filmes presentes nesta versão são apenas exemplos visuais. Antes de publicar conteúdo real, use somente filmes, séries, vídeos, embeds e transmissões para os quais você tenha autorização ou que sejam oferecidos por fontes oficiais/licenciadas.

## Próximo passo
Publicar estes arquivos em uma hospedagem estática gratuita e depois adicionar páginas individuais para filmes, séries e jogos.
