const input = document.getElementById("searchInput");
const cards = [...document.querySelectorAll(".card")];
const matches = [...document.querySelectorAll(".match")];

input.addEventListener("input", () => {
  const term = input.value.trim().toLowerCase();
  cards.forEach(card => {
    card.style.display = !term || card.dataset.title.toLowerCase().includes(term) ? "" : "none";
  });
  matches.forEach(match => {
    match.style.display = !term || match.dataset.title.toLowerCase().includes(term) ? "" : "none";
  });
});

document.querySelectorAll(".filter").forEach(button => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".filter").forEach(b => b.classList.remove("active"));
    button.classList.add("active");
  });
});

document.querySelectorAll(".text-btn").forEach(button => {
  button.addEventListener("click", () => {
    const target = document.getElementById(button.dataset.filter);
    if (target) target.scrollIntoView({behavior:"smooth"});
  });
});
